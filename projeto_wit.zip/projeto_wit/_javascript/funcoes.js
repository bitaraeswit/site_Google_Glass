function mudaFoto(foto){
			document.getElementById("icone").src = "_imagens/"+ foto +".png";
		};